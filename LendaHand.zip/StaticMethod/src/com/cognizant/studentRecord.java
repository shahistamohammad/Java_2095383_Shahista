package com.cognizant;

public class studentRecord {
	private static int scount = 4;
	public static int getstucount(){
		return scount;
	}
}
