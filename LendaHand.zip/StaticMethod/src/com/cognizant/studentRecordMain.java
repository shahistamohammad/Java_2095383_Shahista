package com.cognizant;

public class studentRecordMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("c: " );
studentRecord.getstucount();
	}
}


