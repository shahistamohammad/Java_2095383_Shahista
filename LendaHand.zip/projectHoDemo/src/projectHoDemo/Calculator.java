package projectHoDemo;

public class Calculator {
     int operand1;
     int operand2;
     void displayOperand(){
    	 System.out.println("The value of operand1 is "+operand1);
    	 System.out.println("The value of operand2 is "+operand2);
    	 
     }
     
}
