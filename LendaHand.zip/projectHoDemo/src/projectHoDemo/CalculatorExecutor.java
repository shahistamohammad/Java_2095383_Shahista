package projectHoDemo;
import java.util.Scanner;
public class CalculatorExecutor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sca = new Scanner(System.in);
		System.out.println("The value of operand1 is ");
		int s = sca.nextInt();
		System.out.println("The value of operand2 is ");
		int s1 = sca.nextInt();
		System.out.println("Using Scanner");
		
	Calculator calculator = new Calculator();
	calculator.operand1=s;
	calculator.operand2=s1;
	calculator.displayOperand();
		
	}

}
