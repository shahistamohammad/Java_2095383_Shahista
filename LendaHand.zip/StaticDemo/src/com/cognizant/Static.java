package com.cognizant;

public class Static {
private static int x = 5;
private static int y = 2;
public void displayStatic()
{
	x++;
	y +=5;
	System.out.println("X is :" + x + " Y is:" + y);
}
}
