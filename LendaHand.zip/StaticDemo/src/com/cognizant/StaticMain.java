package com.cognizant;

public class StaticMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the x and y values: ");
 Static sta1 = new Static();
 Static sta2 = new Static();
 Static sta3 = new Static();
 sta1.displayStatic();
 sta2.displayStatic();
 sta3.displayStatic();
	}

}
