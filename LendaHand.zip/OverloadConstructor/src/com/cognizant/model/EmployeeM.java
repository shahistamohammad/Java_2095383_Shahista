package com.cognizant.model;
import java.util.*;
public class EmployeeM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee emp = new Employee();
Scanner scan = new Scanner(System.in);
System.out.println("Enter the empId: ");
emp.setEmpId(scan.nextInt());
System.out.println("Enter employee name: ");
emp.setEmpName(scan.next());
System.out.println("Enter employee Salary: ");
emp.setEmpSalary(scan.nextDouble());

System.out.println("Employee Id: "+ emp.getEmpId());
System.out.println("Employee Name: "+emp.getEmpName());
System.out.println("Employee Salary: "+emp.getEmpSalary());
	}

}
