package com.cognizant;

 class Square extends Shape {
	int length;
	int breadth;
	//float length1/(breadth) = 4;
	public double calculateArea(){
		int areaS = length * breadth;
		System.out.println("Area of the square: "+areaS);
		return areaS;
	}
 }
	