package com.cognizant;

import java.util.Scanner;

public class AbstractDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scan = new Scanner(System.in);
Shape sq = new Square();
double Sq=scan.nextDouble();
System.out.println("Enter area of the square value: "+Sq);
Shape cr = new Circle();
double Cr = scan.nextDouble();
System.out.println("Enter area of the square value: "+Cr);
sq.setColor();
sq.calculateArea();
cr.setColor();
cr.setColor();
	}

}
