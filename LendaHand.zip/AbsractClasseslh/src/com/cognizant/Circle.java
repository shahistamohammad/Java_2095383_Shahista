package com.cognizant;

class Circle extends Shape {
	float r = (float) 5.0;
	double areac = 3.14*r*r;
	public double calculateArea(){
		System.out.println("Area of the circle: "+areac);
		return areac;
	}
	
	}

	