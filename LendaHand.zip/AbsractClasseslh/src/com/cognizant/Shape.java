package com.cognizant;
public abstract class Shape {
String color;
public abstract double calculateArea();


	public void setColor(){
		System.out.println("The color is: "+color);
	}
}
