package pro_Heir_Inh;

public class parent {
 double home;
 public void parentMet(){
	 System.out.println("From parent Method");
 }
}
