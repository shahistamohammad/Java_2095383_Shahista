package com.cognizant;
public class pro_Heir_Inh_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
pro_Heir_Inh_child demo = new pro_Heir_Inh_child();
demo.home = 12359;
demo.parentMet();
demo.access pro_Heir_Inh();
	}

}
