package com.cognizant;

public class pro_Heir_Inh_child extends pro_Heir_Inh{
public void access pro_Heir_Inh(){
	System.out.println("Home :"+home);
}
	
}

