import java.util.Scanner;

//import com.cognizant.Calculator1;
public class CalculatorMainProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scan = new Scanner(System.in);
System.out.println("Using Scanner");
System.out.println("Enter num1: ");
int n1 = scan.nextInt();
System.out.println("Enter num2: ");
int n2 = scan.nextInt();
Calculator1 calculator = new Calculator1();
calculator.num1 = n1;
calculator.num2 = n2;
calculator.addition();
calculator.subtraction();
calculator.printSmaller();
}

}
