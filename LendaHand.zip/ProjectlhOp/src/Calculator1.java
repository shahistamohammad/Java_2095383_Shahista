
public class Calculator1 {
         int num1;
         int num2;
         void addition(){
        	 int num3= num1 + num2;
        	 System.out.println("The sum of two numbers num1 and num2 is "+num3);
         }
        	 void subtraction(){
        		 int num3= num1 - num2;
        		 System.out.println("The sum of two numbers num1 and num2 is "+num3);
        	 }
        		 void printSmaller(){
        			int num3=(num1 < num2)? num1 : num2;
        			 System.out.println("The Smallest of two numbers is "+num3);
        		 }
        	 
         }

