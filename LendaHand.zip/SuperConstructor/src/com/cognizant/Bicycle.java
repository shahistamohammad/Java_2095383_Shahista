package com.cognizant;

public class Bicycle {
public int wheels = 2;
public int speed = 150;
 int gear = 0;
public Bicycle(){
	System.out.println("Inside Bicycle Constructore: ");

}
}
