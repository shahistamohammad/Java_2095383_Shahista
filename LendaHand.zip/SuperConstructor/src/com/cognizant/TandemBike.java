package com.cognizant;

public class TandemBike extends Bicycle {
public int seats = 2;
public int handles = 2;

 
public TandemBike(){
	super();
	super.gear = 2;
	System.out.println("Inside TandemBike constructor: "+gear);
	
}
	// TODO Auto-generated method stub
	//return 0;


public int TandemBike() {
	System.out.println("Bicycle, TandemBike constructor");
	// TODO Auto-generated method stub
	return 0;
}
}


