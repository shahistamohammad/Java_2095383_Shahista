package com.cognizant;
import java.util.Scanner;
//com.cognizant.TandemBike.TandeBike();
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scan = new Scanner(System.in);
TandemBike tb = new TandemBike();
//tb.seats = 3;
//tb.handles = 2;
int seats = scan.nextInt();
int handles = scan.nextInt();
//int seat = tb.TandemBike();
System.out.println("Enter the num of  TandemBike seats: "+seats);
//int handles = tb.TandemBike();
System.out.println("Enter the num of  TandemBike handles: "+handles);

	}

}
