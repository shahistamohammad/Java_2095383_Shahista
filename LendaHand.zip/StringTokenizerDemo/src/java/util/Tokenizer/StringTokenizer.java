package java.util.Tokenizer;

public class StringTokenizer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str = "This is String, split by StringTokenizer, using comma as a delimiter");
StringTokenizer strtkn = new StringTokenizer(str);
while(strtkn.hasMoreToken()){
	System.out.println(strkn.nextToken());
}
	}

}
