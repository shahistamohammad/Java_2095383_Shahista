package com.cognizant;
import java.util.ArrayList;
public class ArrayMain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
ArrayD array = new ArrayD();
array.storeNumbers();
array.printEvenNumbers();
	}

}
