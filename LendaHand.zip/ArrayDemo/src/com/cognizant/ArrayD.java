package com.cognizant;

public class ArrayD {
	int[] num;
	public void storeNumbers(){
		num = new int[101];
		for(int i=0; i<=100; i++){
			num[i] = i;
		}
	}
	public void printEvenNumbers(){
		System.out.println("The even numbers between 0 and 100");
		for(int i=0; i<=num.length; i++){
			if(num[i] % 2 == 0)
				System.out.println("num[i]");
		}
	}
}