package java.lang.pack;

import java.util.*;

public class StringMethodDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "SHaHiSta AdIbA MohaMMaD";
		System.out.println("Name : " + name);
		System.out.println("5th character of Name : " + name.charAt(5));
		System.out.println("Compare to name : " + name.compareTo("SHaHiStA"));
		System.out.println("Replace to name : " + name.replace("AdIbA", "Adiba"));
		System.out.println("Trim the name : " + name.trim());
		System.out.println("Equal the name : " + name.equals("MohaMMaD"));	
		System.out.println("Substring of the name : " + name.substring('S', '5'));
		System.out.println("Concate the name : " + name.concat("AdIbA"));
		System.out.println("Length of the name : " + name.length());
		//System.out.println("Equals ignore case of the name : "+equalsIgnoreCase());
         int index = name.indexOf("A");
         System.out.println("Index of the name : " + name.indexOf('I'));
         String string = name.substring('0', '4');
	}

}
