package com.cognizant;

import java.util.Set;

public class Countries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
public Set getCountries(String c1, String c2, String c3, String c4, String c5){
	Set countries = new HashSet();
	countries.add(c1);
	countries.add(c2);
	countries.add(c3);
	countries.add(c4);
	countries.add(c5);
	return countries;
}
	}

}
