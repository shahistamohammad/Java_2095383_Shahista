package heirInh;
import java.util.*;
public class heirInhMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String c;
		float inc;
		String nam;
		c=sc.nextLine();
		inc=sc.nextFloat();
		nam=sc.nextLine();
child1 demo1 = new child1();
child2 demo2 = new child2();
demo1.car = c;
demo1.income = inc;
demo1.name = nam;
demo2.car = c;
demo2.income = inc;
demo2.name = nam;
demo1.parentProperties();
demo2.parentProperties();


	}

}
