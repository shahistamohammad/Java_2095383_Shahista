package heirInh;

public class parent {
String car;
float income;
String name;
public void parentProperties(){
	System.out.println("Parent proeprties are : "+car);
	System.out.println("Parent proeprties are : "+income);
	System.out.println("Parent proeprties are : "+name);
}

}
