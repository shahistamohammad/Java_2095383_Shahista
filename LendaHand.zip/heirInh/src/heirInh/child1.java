package heirInh;

public class child1 extends parent{
String child1name;
public void child1properties(){
	System.out.println("Parent and child1name: "+child1name);
	System.out.println("Parent and child1name: "+name);

}
}
