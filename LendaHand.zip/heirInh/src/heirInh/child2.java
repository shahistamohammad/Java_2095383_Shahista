package heirInh;

public class child2 extends parent{
	String child2name;
	public void child2properties(){
		System.out.println("Parent and child2name: "+child2name);
		System.out.println("Parent and child2name: "+name);

}
}