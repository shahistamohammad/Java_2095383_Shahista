package com.cognizant;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int area = calculateArea(20);
System.out.println("Area is: "+area);
	}

}
