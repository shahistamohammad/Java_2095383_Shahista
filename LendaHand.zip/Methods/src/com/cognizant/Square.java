package com.cognizant;
import java.util.*;
public class Square {
int area;
public void calcualteArea(int length){
	area = length * length;
	return area;
}
}
