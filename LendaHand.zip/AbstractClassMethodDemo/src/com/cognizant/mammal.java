package com.cognizant;

public abstract  class mammal {
	int noLegs = 4;
 public abstract void animal();
	 
 }


