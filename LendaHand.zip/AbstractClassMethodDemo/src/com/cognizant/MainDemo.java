package com.cognizant;

public class MainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Human hu = new Human();
Object get;
Object noLegs = 4;
System.out.println("\"The mammal is parent class of the human class: \""+noLegs);
hu.set(get(noLegs));
hu.animal();
	}

	private static Object get(Object noLegs) {
		// TODO Auto-generated method stub
		return null;
	}

}
