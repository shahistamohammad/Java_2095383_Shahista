package com.cognizant;

public class Human extends mammal{

	@Override
	public void animal() {
		// TODO Auto-generated method stub
		System.out.println("The mammal is parent class of the human class: "+noLegs);
	}

	public void set(Object noLegs) {
		// TODO Auto-generated method stub
		
	}

}
