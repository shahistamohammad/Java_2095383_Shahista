package com.cognizant;

public class Car extends MoterizedVehicle {
private static final String IVehicle = null;

public String IVehicle(){
	System.out.println("The car is in the brake mode");
	return IVehicle;
}
}
