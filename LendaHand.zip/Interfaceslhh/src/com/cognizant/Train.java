package com.cognizant;

public class Train implements IVehicle,IPublicTransport{

 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

IVehicle vhcl = new IVehicle();   //IVehicle vhcl = new MotarSideVehicle();
system.out.println("The train is turning left");          //Ivehicle.drive();      
vhcl.IVhicle(); //                                 //IVehicle.turnLeft();
vhcl.getNumberOfPeople();                           //IVehicle.brake();
                                                      // IPublicTransport ipt = new checkMotor();
	}                                         // ipt.drive();
                                                  // ipt.turnLeft();
                                                // ipt.brake();

}
