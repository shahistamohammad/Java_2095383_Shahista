package com.cognizant;

public class MoterizedVehicle {
public void checkMotor(){
	System.out.println("The motor of the vehicle is in good condition");
}
}
