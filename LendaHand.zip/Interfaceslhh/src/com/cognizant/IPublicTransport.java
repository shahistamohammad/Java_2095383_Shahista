package com.cognizant;

public interface IPublicTransport {
public void getNumberOfPeople();
}
