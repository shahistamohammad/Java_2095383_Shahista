package com.cognizant;

public interface IVehicle {
public void drive();
public void turnLeft();
public void brake();
}
