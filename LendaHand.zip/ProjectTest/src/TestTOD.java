import java.io.*;
public class TestTOD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int num1=10;
          int num2;
          num2=(num1>15)? 20 : 30;
          System.out.println("Value od num2 is: "+num2);
       
        
	}

}
