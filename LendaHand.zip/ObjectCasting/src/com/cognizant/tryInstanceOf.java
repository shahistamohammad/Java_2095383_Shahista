package com.cognizant;

public class tryInstanceOf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
BankAccount o1 = new NRIAccount();
BankAccount o2 = new NRIAccount();
BankAccount o3 = new SeniorCitizenAccount();
if(o1 instanceof NRIAccount){
	System.out.println("Can o1 typecast NRIAccount");
	o1 = o2;
}else {
	System.out.println("Can o1 typecast NRIAccount");

	}
}
if(o3 instanceof NRIAccount){
	System.out.println("Can o3 typecast NRIAccount");
	o3 = o2;
}	else{
	System.out.println("can not o3 typecast NRIAccount");
}
}
implicitCasting();
explicitCasting();
tryInstanceOf();
}
