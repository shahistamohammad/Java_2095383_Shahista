package com.cognizant;

public class NRIAccount {

	public void dipositeMoney() {
		// TODO Auto-generated method stub
		
	}

}
