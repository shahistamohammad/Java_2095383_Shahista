package com.cognizant;

public class BankAccount {

	public int dipositAmount;

	public void applyFixedDeposite() {
		// TODO Auto-generated method stub
		
	}

}
