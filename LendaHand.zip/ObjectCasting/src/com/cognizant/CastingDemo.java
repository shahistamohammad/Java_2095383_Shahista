package com.cognizant;

public class CastingDemo {
public static void impliciCasting(){
	NRIAccount o = new NRIAccount();
	BankAccount v1;
	v1 = o;
	v1.applyFixedDeposite();
  }
public static void explicitCasting(){
	BankAccount o = new NRIAccount();
	NRIAccount v1;
	o.dipositAmount = 3500;
	v1 = (NRIAccount) o;
	v1.dipositeMoney();
}
}
