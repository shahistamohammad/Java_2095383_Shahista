package com.cognizant;

import java.util.Set;

public class SetExMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
SetEx ex1 = new SetEx();
System.out.println(ex1.Countries("India, Saudi,Iran,Iraq,Italy,Pakistan", null, null));
Set num1to10 = ex1.get1to10();
System.out.println(num1to10);
System.out.println(ex1.get11to15(num1to10));
	}

}
