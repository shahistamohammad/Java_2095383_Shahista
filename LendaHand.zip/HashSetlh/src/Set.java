import java.util.*;
public class Set {
private static final SetEX HashSet = null;

public java.util.HashSet Countries(String c1, String c2, String c3){
	HashSet countries = new HashSet();
	countries.add(c1);
	countries.add(c2);
	countries.add(c3);
	return countries;
}

private void add(int i) {
	// TODO Auto-generated method stub
	
}
public java.util.HashSet get1to10(){
	java.util.HashSet numSet = new HashSet();
	for(int i =0; i<10; i++)
		numSet.add(i);
	return numSet;
}
public java.util.HashSet get11to15(Set numSet1){
	java.util.HashSet numSet2 = new HashSet();
	for(int i=0; i <=15; i++)
		numSet2.add(i);
	return numSet2;
}
}