
public class EmployeeMain {

	public static void main(String[] args) {
		                                      // TODO Auto-generated method stub
     Employee employee = new Employee();
     employee.empId = 1234;
     employee.empName = "John";
     employee.empSalary = 25000;
      
     employee.displayEmployee();
	}
}
