
public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
   int empId;
   String empName;
   double empSalary;
   
   void displayEmployee(){
	   System.out.println("EmployeeId :"+empId);
	   System.out.println("EmployeeName :"+empName);
	   System.out.println("EmployeeSalary :"+empSalary);
	   
   }
}
