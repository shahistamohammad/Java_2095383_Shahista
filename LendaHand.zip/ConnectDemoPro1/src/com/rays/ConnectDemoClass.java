package com.rays;
import java.sql.SQLException;
import java.sql.Driver;
import java.sql.DriverManager;
public class ConnectDemoClass {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
//Load a Driver
		Driver drv = new com.mysql.cj.jdbc.Driver();
		DriverManager.registerDriver(drv);
		
//Connect to the DataBase
		DriverManager.getConnection("jdbc:mysql://localhost:3306/ipm","root","root");
		System.out.println("Connected...");
	}

}
