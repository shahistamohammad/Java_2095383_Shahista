package com.cognizant;

public interface IVehicle {
public void brake();
public void turnLeft();
public void drive();

}
