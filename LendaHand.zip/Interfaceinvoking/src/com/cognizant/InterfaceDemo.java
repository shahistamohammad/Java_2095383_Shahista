package com.cognizant;

import com.cognizant.InterfaceDemo.Car;

public class InterfaceDemo {

	public class Car {

		public void checkMotor() {
			// TODO Auto-generated method stub
			
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
IVehicle vehicleobj = new car(); //invoke the drive and brake method on the car object
vehicleobj.drive();
vehicleobj.brake();

Car car = new Car();
car.checkMotor();

	IVehicle veh = new Train();
	veh.drive();
	veh.brake();
	
	IPublicTransport publicTransportobj = (IPublicTransport) new Train();
	publicTransportobj.getNumberOfPeople();
}

	private static void car() {
		// TODO Auto-generated method stub
		
	}
}
