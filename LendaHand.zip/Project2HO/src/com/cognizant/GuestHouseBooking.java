package com.cognizant;

import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
public class GuestHouseBooking {
	int noRooms;
	int noPersons;
	int noDays;
	String bookingDate;
	public boolean checkAvailability() throws ParseException
	{
		boolean flag=false;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the date on which you want to book the room:");
		bookingDate=sc.next();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
		Date currDate=sdf.parse("2022-01-06");
		Date gvnDate=sdf.parse(bookingDate);
		Date endDate=sdf.parse("2022-01-20");
		if((gvnDate.after(currDate)) && (gvnDate.before(endDate)))
			flag=true;
			//System.out.println("Yayy!Rooms Available");
		else
			flag=false;
			//System.out.println("Sorry!Insufficient rooms:(");
		return flag;
	}
	public void reservation() throws ParseException
	{
		int choice;
		Scanner sc=new Scanner(System.in);
		System.out.println("        Menu\n======================\n1.AC room(Rs.1000/-)\n2.Non-AC room(Rs.750/-)\n3.TV in room(Rs.1200/-)\n4.Wifi in room(Rs.1500/-)");
		System.out.println("Please select your choice:");
		choice=sc.nextInt();
		if(choice==1){
			System.out.println("For how many days you want to book this room?");
			noDays=sc.nextInt();
			float cost=noDays*1000;
			if(checkAvailability()){
			System.out.println("AC room booked successfully on "+bookingDate+ " for "+noDays+" days.");
			System.out.println("Total fare:"+cost);
			}
			else
				System.out.println("Sorry!Insufficient rooms:(");
			//s="AC room";
		}
		else if(choice==2){
			System.out.println("For how many days you want to book this room?");
			noDays=sc.nextInt();
			float cost=noDays*750;
			if(checkAvailability()){
			System.out.println("Non-Ac room booked successfully on "+bookingDate+" for "+noDays+" days.");
			System.out.println("Total fare:"+cost);
			}
			else
				System.out.println("Sorry!Insufficient rooms:(");
			//s="Non-AC room";
		}
		else if(choice==3){
			System.out.println("For how many days you want to book this room?");
			noDays=sc.nextInt();
			float cost=noDays*1200;
			if(checkAvailability()){
			System.out.println("Room with TV booked successfully on "+bookingDate+" for "+noDays+" days.");
			System.out.println("Total fare:"+cost);
			}
			else
				System.out.println("Sorry!Insufficient rooms:(");
			//s="TV room";
		}
		else if(choice==4){
			System.out.println("For how many days you want to book this room?");
			noDays=sc.nextInt();
			float cost=noDays*1500;
			if(checkAvailability()){
			System.out.println("Room with Wifi booked successfully on "+bookingDate+" for "+noDays+" days.");
			System.out.println("Total fare:"+cost);
			}
			else
				System.out.println("Sorry!Insufficient rooms:(");
			//s="Wifi room";
		}
		else
			System.out.println("Incorrect choice!");
	}
}
