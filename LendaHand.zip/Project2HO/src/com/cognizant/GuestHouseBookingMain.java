package com.cognizant;

import java.text.ParseException;

public class GuestHouseBookingMain {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		GuestHouseBooking c1=new GuestHouseBooking();
		c1.reservation();
	}
}
