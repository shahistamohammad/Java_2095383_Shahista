package com.cognizant;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
StudentClass stud = new StudentClass();
stud.setStuName("Ahan");
stud.setM1(50);
stud.setM2(40);
stud.setM3(20);
ResultCalculator res = new ResultCalculator();
ResultClass result = new ResultClass();
//result.setRegNo(101);
ResultClass ret = res.cal(stud);
System.out.println("Student regNo: "+ret.getRegNo() +"\n"+ "Result: " +ret.getGrade() +"\n"+ "StudentName: "+ret.getStuName());

	}
	
}
