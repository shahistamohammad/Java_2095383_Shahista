package com.cognizant;

public class ResultCalculator {
public ResultClass cal(StudentClass studentclass ){
	int total = studentclass.getM1() + studentclass.getM2() + studentclass.getM3();
	int avg = total/3;
	ResultClass result = new ResultClass();
	result.setRegNo(101);
	result.setStuName("Ahan");
	if(avg >40){
		result.setGrade("Pass");
	}
	else{
			result.setGrade("Fail");
	}
	return result;
}
}
	


