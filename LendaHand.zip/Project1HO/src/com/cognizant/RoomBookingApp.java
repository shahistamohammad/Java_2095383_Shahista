package com.cognizant;
import java.util.*;
public class RoomBookingApp {
	String custName;
	String emailId;
	long mobileNo;
	String s;
	static int counter=0;
	RoomBookingApp()
	{
		counter++;
	}
	public void Registration()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Name:");
		custName=sc.next();
		System.out.println("Enter your Email Id:");
		emailId=sc.next();
		System.out.println("Enter your Mobile Number:");
		mobileNo=sc.nextLong();
		System.out.println("Successfully Registered!");
	}
	public void Book()
	{
		int choice;
		//String s = null;
		Scanner sc=new Scanner(System.in);
		System.out.println("1.AC room(Rs.1000/-)\n2.Non-AC room(Rs.750/-)\n3.TV in room(Rs.1200/-)\n4.Wifi in room(Rs.1500/-)");
		System.out.println("Please select your choice:");
		choice=sc.nextInt();
		if(choice==1){
			System.out.println("AC room booked successfully!");
			s="AC room";
		}
		else if(choice==2){
			System.out.println("Non-Ac room booked successfully!");
			s="Non-AC room";
		}
		else if(choice==3){
			System.out.println("Room with TV booked successfully!");
			s="TV room";
		}
		else if(choice==4){
			System.out.println("Room with Wifi booked successfully!");
			s="Wifi room";
		}
		else
			System.out.println("Incorrect choice!");
		//return s;
	}
	public void checkStatus()
	{
		if(counter>3)
			System.out.println("Oops!Rooms are already booked!");
		else
			System.out.println("Hey!Rooms are vacant!");
	}
	public void changeEmail()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter your new email id:");
		String newemail=sc.nextLine();
		emailId=newemail;
		System.out.println("Your new email id updated successfully!");
	}
	public void displayBookings()
	{
		System.out.println("Booked room is:"+s);
	}
	public void displayCustomers()
	{
		System.out.println("The customer details are:");
		System.out.println("Customer Name:"+custName);
		System.out.println("Customer Email:"+emailId);
		System.out.println("Customer Mobile Number:"+mobileNo);
	}
}
