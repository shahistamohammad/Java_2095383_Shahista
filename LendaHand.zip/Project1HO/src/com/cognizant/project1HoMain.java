package com.cognizant;

import java.util.Scanner;

public class project1HoMain {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RoomBookingApp obj= new RoomBookingApp();
		int ch;
		Scanner sc=new Scanner(System.in);
		
		while(true)
		{
			
			System.out.println("    Menu\n============\n1.Register\n2.Book\n3.Check Status\n4.Email\n5.All Bookings\n6.All customers\n7.Quit");
			System.out.println("Please enter your choice:");
			ch=sc.nextInt();
			if(ch==1)
			{
				System.out.println("Are you sure you want to continue?Please enter y/n:");
			    String yn=sc.next();
			    if(yn.equals("y"))
			    {
			    	//System.out.println("Entered inside if");
			       //Lang_Fund_Operators obj= new Lang_Fund_Operators();
			       obj.Registration();
			    }
			} 
			else if(ch==2)
			{
				System.out.println("Are you sure you want to continue?Please enter y/n:");
			    String yn=sc.next();
			    if(yn.equals("y"))
			    {
			       //Lang_Fund_Operators obj= new Lang_Fund_Operators();
			       obj.Book();
			    }      	
			}
			else if(ch==3)
			{
				System.out.println("Are you sure you want to continue?Please enter y/n:");
			    String yn=sc.next();
			    if(yn.equals("y"))
			    {
			       //Lang_Fund_Operators obj= new Lang_Fund_Operators();
			       obj.checkStatus();
			    }      	
			}
			else if(ch==4)
			{
				System.out.println("Are you sure you want to continue?Please enter y/n:");
			    String yn=sc.next();
			    if(yn.equals("y"))
			    {
			       //Lang_Fund_Operators obj= new Lang_Fund_Operators();
			       obj.changeEmail();
			    }      	
			}
			else if(ch==5)
			{
				System.out.println("Are you sure you want to continue?Please enter y/n:");
			    String yn=sc.next();
			    if(yn.equals("y"))
			    {
			       //Lang_Fund_Operators obj= new Lang_Fund_Operators();
			       obj.displayBookings();
			    }      	
			}
			else if(ch==6)
			{
				System.out.println("Are you sure you want to continue?Please enter y/n:");
			    String yn=sc.next();
			    if(yn.equals("y"))
			    {
			       //Lang_Fund_Operators obj= new Lang_Fund_Operators();
			       obj.displayCustomers();
			    }      	
			}
			else if(ch==7)
			{
				System.out.println("Bye bye!");
				break;
			}
		}
	}
}
