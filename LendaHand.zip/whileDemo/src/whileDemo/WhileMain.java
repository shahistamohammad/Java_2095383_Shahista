package whileDemo;

public class WhileMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int count = 10;
whileclass wc = new whileclass();

while (count>0){
	wc.message();
	count ++;
}

	}

}
