package com.cognizant;

public class whileclass {
      void message(){
    	  System.out.println("Welcome Everyone");
      }
}
