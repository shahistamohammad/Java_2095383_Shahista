package com.cognizant;

public class StingBufferApi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
StringBufferApi sba = new StringBufferApi("Hello");
System.out.println(sba.length());
sba.append("world");
System.out.println(sba);
sba.insert(5,"_Java");
System.out.println(sba);
sba.charAt(5, '');
sba.replace(5,' ');
System.out.println("At 6th position : ");
sba.charAt(6);
sba.delete(3);
System.out.println("Capacity of the StringBuffer Object : ");
sba.capacity();
sba.reverse();
System.out.println("Reversed String : ");
System.out.println(sba.reverse());

	
	}

}
