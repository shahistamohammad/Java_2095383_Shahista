package com.statements.demo;

public class TesProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int j;
		int count=5;
WelcomeMessage wm = new WelcomeMessage();
for(j=1;j<=count;j++){
	wm.printMessage();
	if(j==3){
		System.out.println("After if loop:"+j);
	}
}System.out.println("Final returend value of j is: "+j);
	}
}
