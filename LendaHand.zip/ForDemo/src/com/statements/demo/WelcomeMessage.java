package com.statements.demo;

public class WelcomeMessage {
	int i;
  void printMessage(){
	  System.out.println("Welocme All");
  }
}
