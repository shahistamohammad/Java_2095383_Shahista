package com.cognizant;
public class StringBuilder {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
StringBuilder strbld = new StringBuilder("Hello");
System.out.println(strbld.length());
strbld.append("world");
System.out.println(strbld);
strbld.insert(5,"_Java ");
System.out.println(strbld);
strbld.replace(5,'');
System.out.println(strbld);
	}

}
