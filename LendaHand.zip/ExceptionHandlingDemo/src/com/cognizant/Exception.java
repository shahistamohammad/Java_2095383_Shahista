package com.cognizant;

public class Exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
float value = 17%3;
float result = value + 3;
System.out.println("show result: "+result);

	}

}
