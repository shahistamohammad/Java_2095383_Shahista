package com.cognizant;

public class Employee {
    long empId;
    double empSalary;
    float empTax;
    int empDaysOfWork;
    
    void calculatePF(double sal){
    	float pfRate = 10.5f;
    	double pfRate1 = 10.5*sal;
    	System.out.println("The PF Rate Of An Employee is "+pfRate1);
    }
}
