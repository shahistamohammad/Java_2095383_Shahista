package com.cognizant;
import java.io.*;
import java.util.Scanner;

public class EmployeeMainProgram {

	public static void main(String[] args){
		// TODO Auto-generated method stub
           Scanner scanner = new Scanner(System.in);
           System.out.println("Using Scanner");
           System.out.println("The Id of an Employee is ");
           int id = scanner.nextInt();
           System.out.println("The Salary of an Employee is ");
           double sal = scanner.nextDouble();
           System.out.println("The percentage of Tax The Employee needs to pay is ");
           float tax = scanner.nextFloat();
           System.out.println("The Total Number Of Working day is ");
           int work = scanner.nextInt();
           Employee employee = new Employee();
           employee.empId = id;
           employee.empSalary = sal;
           employee.empTax = tax;
           employee.empDaysOfWork = work;
           employee.calculatePF(sal);
	}

}
