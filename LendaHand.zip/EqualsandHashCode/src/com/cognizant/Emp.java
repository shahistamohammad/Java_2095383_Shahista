package com.cognizant;

public class Emp {
private int age;
public Emp(){
	super();
	this.age = age;
}
public int hashCode(){
	return age;
}
public boolean equals(){
	Emp em = (Emp) obj;
	boolean flag;
	if(em.age = age)
		flag = true;
	return flag;
}
}
