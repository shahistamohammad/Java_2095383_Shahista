package com.cognizant;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Emp emp1 = new Emp(23);
Emp emp2 = new Emp(23);
System.out.println("emp1.equals(emp2) :"+emp1.equals(emp2));
emp1.hashCode;
emp1.Emp();
emp1.equals();
emp2.hashCode();
emp2.Emp();
emp2.equals();

	}

}
