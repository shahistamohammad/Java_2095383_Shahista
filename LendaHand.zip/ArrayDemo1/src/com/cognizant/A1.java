package com.cognizant;

import java.util.Scanner;

public class A1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//int regnum[] = {101,102,103,104,105};
//for(int a : regnum){
	//System.out.println(a);
//}
	//}
	String stuName[] = new String[5];
	int renum[] = new int[5];
	long mobile[] = new long[10];
	Scanner sc =new Scanner(System.in);{
	for(int i=0; i<=5; i++){
		System.out.println("Enter regnum: ");
		int[] regnum = null;
		int mobile1; 
		regnum[i] = sc.nextInt();
		System.out.println("Enter stuName:");
		stuName[i] = sc.next();
		System.out.println("Enter mobile: ");
		mobile1 = (int) sc.nextLong();
	}
 }
}
}

