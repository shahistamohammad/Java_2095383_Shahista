package com.cognizant;

public class A {
int regnum[] = {101,102,103,104,105};

}
