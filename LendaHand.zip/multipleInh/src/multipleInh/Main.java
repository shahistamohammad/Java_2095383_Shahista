package multipleInh;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		child demo = new child();
		demo.property = "HouseLand";
		demo.car = "Swift";
		demo.land = "HospitalLand";
		demo.fathername = "Sonu";
		
		demo.Jewels = "Gold";
		demo.mothername = "Sana";
		demo.dna = "XYZ";
		
		demo.empname = "Sony";
		demo.idnum = 123;
		demo.childname ="sona";
		
		demo.displayFather();
        demo.displayMother();
        demo.displaychild();

	}

}
