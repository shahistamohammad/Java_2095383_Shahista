package multipleInh;

public class child extends Father{
 String empname;
 int idnum;
 String childname;
 public void displaychild(){
	 System.out.println("Child properties from parents are: "+empname);
	 System.out.println("Child properties from parents are: "+idnum);
	 System.out.println("Child properties from parents are: "+childname);
	
 }
}
