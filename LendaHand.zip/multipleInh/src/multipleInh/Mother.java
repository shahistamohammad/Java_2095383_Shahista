package multipleInh;

public class Mother {
String Jewels;
String mothername;
String dna;
public void displayMother (){
	System.out.println("Mother Properties are:"+Jewels);
	System.out.println("Mother Properties are:"+mothername);
	System.out.println("Mother Properties are:"+dna);
}
}
