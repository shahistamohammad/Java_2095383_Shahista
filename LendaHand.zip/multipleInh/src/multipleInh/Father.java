package multipleInh;

public class Father {
float property;
String car;
double land;
String fathername;
public void displayFather(){
	System.out.println("Father properties are: "+property);
	System.out.println("Father properties are: "+car);
	System.out.println("Father properties are: "+land);
	System.out.println("Father properties are: "+fathername);
}
}
