package com.cognizant;

public class BankAccount1 {
//	public double withdrawAmount;
	//public double depostiAmount;
	//public double interestRate = 9.5;
	//public double balance;
	public double interestRate = 8;
public void applyFixedDeposite(){
	System.out.println("DipositRate is: "+interestRate);
}
}
	//public double dipositMoney(){
		//double depositAmount = 2576;
		//balance = depositAmount - withdrawAmount;
		//double depositAmount1 = 2346;
		//System.out.println("The despositAmount:"+depositAmount1);
		//return balance;
		
	//}
	//public double withdrawMoney(){
		
		//double withdrawMoney = 2363;
		//System.out.println("The withdrawMoney is: "+withdrawMoney);
		//return balance;
		
	//}
	//}
//}
