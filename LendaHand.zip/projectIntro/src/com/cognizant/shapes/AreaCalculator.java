package com.cognizant.shapes;
import java.util.Scanner;
public class AreaCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Input: ");
    Rectangle rectangle = new Rectangle();
     rectangle.length = scan.nextInt();
     rectangle.breadth = scan.nextInt();
     rectangle.calculateArea();
	}

}
