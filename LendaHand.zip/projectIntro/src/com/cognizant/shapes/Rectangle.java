package com.cognizant.shapes;

public class Rectangle {
     int length;
     int breadth;
     public void calculateArea(){
    	 int area = length * breadth;
    	 System.out.println("The Area of the Rectangle is calulated "+ "Using the formula length * breadth "+area);
     }
}
