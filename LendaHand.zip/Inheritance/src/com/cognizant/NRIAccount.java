package com.cognizant;
import java.util.*;
public class NRIAccount extends BankAccount{
	
	public double applyFixedDeposite(){
		 interestRate = 6.5;
		System.out.println("The interestRate: "+interestRate);
		return balance;

}
	}
