package com.cognizant;

public class SeniorCitizen extends BankAccount{

	public double applyFixedDeposite(){
		 interestRate = (double)10.5;
		System.out.println("The interestRate is: "+interestRate);
		return balance;
	}
}
