package com.cognizant;

public class inheritanceMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
SeniorCitizen src = new SeniorCitizen();
NRIAccount nria = new NRIAccount();
src.interestRate = 34567;
nria.interestRate = 23874;
double n1 = src.dipositMoney();
System.out.println("Show the dipositAmount here 1st time");
double n2 = src.withdrawMoney();
System.out.println("show the withdarwMoney here 2nd time");
double n3 = nria.dipositMoney();
System.out.println("Display the dipositAmount here 1st time");
double n4 = nria.withdrawMoney();
System.out.println("Display the withdrawMoney here 2nd time");
double n5 = src.applyFixedDeposite();
System.out.println("Show the dipositAmount to applyfixedDeposite here 1st time");
double n6 = nria.applyFixedDeposite();
System.out.println("Show the withdrawAmount to applyfixedDeposite here 2nd tim");
	}
}
