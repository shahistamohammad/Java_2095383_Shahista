package com.rays;

public class FacebookProfile {
private String maritalStatus;
private String phoneNumber;
private int age;

   public String getmaritalStatus(){
	   return maritalStatus;}
   
	   public void setmaritalStatus(String maritalStatus){
		   this.maritalStatus = maritalStatus;
		   }
	   public String getphoneNumber(){
		   return phoneNumber;
	   }
	   public void setphonenumber(String phoneNumber){
		   this.phoneNumber = phoneNumber;
		   }
	   public int getage(){
		   return age;
	   }
	   public void setage(int age){
		   this.age = age;
	   }
	   }

