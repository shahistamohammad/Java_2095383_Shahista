package com.rays;

public class AccessFacebookProfile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
FacebookProfile accessprofile = new FacebookProfile();
accessprofile.setmaritalStatus("Single");
accessprofile.setphonenumber("123456799");
accessprofile.setage(23);
System.out.println("MaritalStatus: "+accessprofile.getmaritalStatus() +" "+ "PhoneNumber: "+accessprofile.getphoneNumber() +" age: "+accessprofile.getage());}
	}
