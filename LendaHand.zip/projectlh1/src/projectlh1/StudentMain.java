package projectlh1;
import java.util.*;
public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int regid;
		Scanner in = new Scanner(System.in);
		System.out.print("Enter your registration id: ");
		regid=in.nextInt();
		Student student= new Student();
		student.registrationId=regid;
		student.displayReistrationId();

	}

}
