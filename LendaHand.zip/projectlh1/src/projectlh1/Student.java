package projectlh1;

public class Student {
	int registrationId;
	void displayReistrationId()
	{
		System.out.println("The student registration id is: "+registrationId);
	}

}
