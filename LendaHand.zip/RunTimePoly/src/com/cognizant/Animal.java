package com.cognizant;
 class Animal {
void whoAmI(){
	System.out.println("I am a generic Animal");
	
}
}
