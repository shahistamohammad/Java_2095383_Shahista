package com.cognizant;

 class Dog extends Animal{
	 void whoAmI(){
		
System.out.println("I am a Dog");
}
 }
