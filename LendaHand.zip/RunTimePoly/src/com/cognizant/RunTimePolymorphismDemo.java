package com.cognizant;

public class RunTimePolymorphismDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Animal a = new Animal();
Animal b = new Dog();
Animal c = new Cow();
Animal d = new Snake();

a.whoAmI();
b.whoAmI();
c.whoAmI();
d.whoAmI();
	}

}
