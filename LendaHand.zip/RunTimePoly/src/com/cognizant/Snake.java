package com.cognizant;

public class Snake extends Animal {
void whoAmI(){
	System.out.println("I am a Snake");
}
}
