package com.cognizant;

public class Cow extends Animal{
 void whoAmI(){
	 System.out.println("I am a Cow");
 }
}
