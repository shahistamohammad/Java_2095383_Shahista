
public class OverloadDemo {
void test(){
	System.out.println("No parameters:");
}
void test(int a){
	System.out.println("one parameter a: "+a);
}
void test(int a, int b){
	System.out.println("Two parameters a and b: "+ a + b);
}
double test(double a){
	System.out.println("double parameter: "+a);
	return a * a;
}
}
