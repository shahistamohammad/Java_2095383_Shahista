
public class OverloadMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
OverloadDemo demo = new OverloadDemo();
double result;
demo.test();
demo.test(10);
demo.test(20);
result =  demo.test(23.87);
System.out.println("Result of demo.tes(23.87): "+result);
	}
}
