package com.cognizant;

public class numberCheck {
public void displayBiggerNumber(int n1,int n2,int n3){
 int BiggerNumber;
 if(n1>n2){
	 if(n1>n3){
		System.out.println("biggestNumber: "+ n1);
}else if(n3>n2){
	System.out.println("biggestNumber: "+n3);
}else{
	System.out.println("biggestnnumber: "+ n2);
 }
	 }else if(n2>n3){
	 System.out.println("biggestNumber:"+ n2);
 }else {
	 System.out.println("biggestNumber: "+ n3);
}
 System.out.println(" Is the biggestNumber");
}
}