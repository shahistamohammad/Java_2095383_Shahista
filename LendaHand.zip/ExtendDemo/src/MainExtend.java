import java.util.Scanner;

public class MainExtend {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//ScientificCal sc = new ScientificCal();
//sc.val1 = 2;
//sc.val2 = 3;
//double va = sc.calculateSineValue();
//System.out.println("Enter value: "+va);
//double va1 = sc.calculateCosValue();
//System.out.println("Enter value: "+va1);
	//}
//}
ScientificCal sc = new ScientificCal();
Scanner scanner = new Scanner(System.in);
System.out.println("Enter the first value: ");
double val1 = scanner.nextDouble();
System.out.println("Enter the second vale: ");
double val2 = scanner.nextDouble();
sc.calculateCosValue();

sc.calculateSineValue();
	}
}
//
//
