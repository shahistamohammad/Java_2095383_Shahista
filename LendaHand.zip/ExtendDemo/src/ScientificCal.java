import java.util.*;
public class ScientificCal extends BasicCal{
public double calculateSineValue(){
	double sineValue = Math.sin(val1);
	System.out.println("Enter sineValue: "+sineValue);
	return sineValue;
}
public double calculateCosValue(){
	double cosValue = Math.cos(val2);
	System.out.println("Enter cosValue: "+cosValue);
	return cosValue;
}
}
