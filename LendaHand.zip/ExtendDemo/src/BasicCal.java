
public class BasicCal {
int val1;
int val2;
public int addition(){
	int sum = val1 + val2;
	return sum;
}
	
public int subtraction(){
	int dif = val1 - val2;
	return dif;
}
}

