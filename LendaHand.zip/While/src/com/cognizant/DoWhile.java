package com.cognizant;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i = 10;
do{
	System.out.println("i is :"+i);
	i++;
	if(i==200){
		break;
	}
}while (i>5);
	}

}
