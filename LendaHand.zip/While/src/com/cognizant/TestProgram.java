package com.cognizant;

public class TestProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count = 10;
WelcomeMessage message = new WelcomeMessage();
while (count>1){
	message.printMessage();
	count --;
	}

}

	}
