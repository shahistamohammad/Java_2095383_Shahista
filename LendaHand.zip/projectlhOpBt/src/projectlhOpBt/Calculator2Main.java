package projectlhOpBt;

import java.util.Scanner;

public class Calculator2Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner scan = new Scanner(System.in);
    System.out.println("Enter num1: ");
    int n1 = scan.nextInt();
    System.out.println("Enter num2: ");
    int n2 = scan.nextInt();
    Calculator2 cal = new Calculator2();
    cal.num1 = n1;
    cal.num2 = n2;
    cal.bitwiseAND();
    cal.bitwiseOR();
    cal.bitwiseXOR();
    cal.bitwiseNOT();
   
	}

}
