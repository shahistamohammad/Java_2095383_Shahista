package projectlhOpBt;

public class Calculator2 {
int num1;
int num2;
 void bitwiseAND(){
	 int num3 = num1 & num2;
	 System.out.println("The Bitwise AND of " + "The TWO Numbers num1 and num2 is "+num3);
 }
 void bitwiseOR(){
	 int num3 = num1 | num2;
	 System.out.println("The Bitwise of OR of "+ "The Two Numbers num1 and num2 is "+num3);
 }
 void bitwiseXOR(){
	 int num3 = num1 ^ num2;
	 System.out.println("The Bitwise of XOR of "+ "The Two Numbers num1 and num2 is "+num3);
 }
 void bitwiseNOT(){
	 int num3 = ~ num2;
	System.out.println("The Bitwise of NOT of "+ "The Two Numbers num1 and num2 is "+num3);
}
}