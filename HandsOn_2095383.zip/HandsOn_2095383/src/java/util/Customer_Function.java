package java.util;
import java.util.List;
public interface Customer_Function {

	public int addCustomer_Details(Customer_Details customer);
	public List<Customer_Details> getAllCustomer_Details();
	public List<Customer_Details> getCustomer_DetailsByDate();
	public int updateCustomer_Details(Customer_Details customer);
	public int bookCustomer_Room();
}
